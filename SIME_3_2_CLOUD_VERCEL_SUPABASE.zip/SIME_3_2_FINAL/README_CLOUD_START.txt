SIME 3.2 - CLOUD (VERCEL + SUPABASE)


1) Read DEPLOY_VERCEL_SUPABASE.md first.
2) This package is configured for Flask on Vercel and Supabase PostgreSQL.
3) Do not put real database credentials in the ZIP or Git repository.
4) Set DATABASE_URL, SIME_SECRET, SIME_ADMIN_USERNAME and SIME_ADMIN_PASSWORD
   in Vercel Project Settings > Environment Variables, then deploy/redeploy.
5) SQLite remains available for local desktop mode when DATABASE_URL is unset.

This ZIP is prepared for deployment; it is not already online. Test every
workflow after the first deployment, especially login, ticket creation,
admin user management, equipment, floor maps, and reports.
