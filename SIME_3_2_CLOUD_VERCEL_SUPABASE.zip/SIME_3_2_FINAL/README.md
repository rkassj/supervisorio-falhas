# SIME 3.2 — Supervisório e Mapa SCADA ilustrativo

Painel industrial com autenticação e três perfis: Produção, Manutenção e Administrador. Centraliza ocorrências, acompanhamento de manutenção, indicadores e inventário por piso.

## Requisitos
- Windows 10/11
- Python 3.10 ou superior
- Acesso à internet na primeira instalação (para instalar Flask e dependências)
- Navegador atualizado

## Instalação e execução
1. Extraia a pasta `SIME_2_1` em um local com permissão de gravação.
2. Instale Python 3.10+ e marque a opção de adicionar Python ao PATH.
3. Execute `INICIAR_SIME.bat`.
4. Aguarde a criação do ambiente virtual e a instalação das dependências.
5. O navegador abrirá em `http://127.0.0.1:5000`.

O banco `sime.db` é criado automaticamente na primeira execução, na pasta `instance/` do projeto. Não exclua esse arquivo se quiser preservar os registros.

## Acesso inicial e perfis

Na primeira execução, o sistema cria três contas de demonstração. **Altere as senhas após o primeiro acesso e antes de disponibilizar o sistema na rede da fábrica.**

| Perfil | Usuário inicial | Senha inicial | Permissões |
|---|---|---|---|
| Administrador | `admin` | `admin12345` | Acesso completo, cadastro de usuários, permissões, equipamentos, inventário e configurações operacionais |
| Manutenção | `manutencao` | `manut12345` | Supervisório, central de chamados, atendimento, histórico, gráficos e indicadores |
| Produção | `producao` | `prod12345` | Abrir chamados, informar sintoma e causa, consultar os próprios chamados |

O administrador cria novos usuários em **Usuários e acessos** e escolhe o perfil. Cada pessoa pode alterar a própria senha pelo menu **Alterar minha senha**. A tela de login encaminha cada pessoa para sua área. A produção não acessa gráficos, cadastro de equipamentos nem a gestão técnica dos chamados. A manutenção recebe os chamados e registra responsável, diagnóstico, peças e solução.

## Inventário por piso

O sistema importa automaticamente, no primeiro início da versão 3.0, os equipamentos e pontos listados pelo usuário, agrupados do 1º ao 6º piso, com as conexões transcritas no **Mapa por piso**. O inventário importado é inicial e não sobrescreve equipamentos já existentes.

**Atenção à validação em campo:** a lista original contém códigos repetidos em pisos/áreas diferentes e algumas referências ambíguas. Para evitar colisões no banco, algumas ocorrências repetidas receberam sufixos de localização (por exemplo, `-6D`, `-6E` ou `-6C`). Confirme esses casos com a equipe antes de usar o inventário como identificação oficial. As conexões representam a transcrição das anotações, não uma validação técnica do fluxo físico.

## Fluxo de trabalho

1. Produção entra no sistema, seleciona o equipamento, descreve o sintoma observado, informa a causa conhecida (ou registra que ainda não foi identificada) e indica se o equipamento está parado.
2. O chamado aparece na central de manutenção.
3. Manutenção assume o chamado, registra diagnóstico, peças utilizadas e solução, e encerra o atendimento.
4. O supervisório atualiza o estado dos equipamentos e os indicadores; a produção acompanha os próprios chamados.
5. O administrador mantém os usuários, permissões e cadastro dos ativos.

## Rotas principais
- `/login` — autenticação
- `/perfil/senha` — alteração de senha do usuário autenticado
- `/` — dashboard e mapa operacional dos seis andares
- `/planta` — inventário e conexões agrupados por piso (administrador)
- `/admin/usuarios` — gestão de usuários (administrador)
- `/meus-chamados` — acompanhamento da produção
- `/novo` — abertura de chamado (produção/administrador)
- `/historico` — histórico
- `/chamado/<id>` — gestão de chamado
- `/equipamentos` — cadastro e listagem
- `/equipamento/<id>` — ficha individual
- `/equipamento/<id>/editar` — edição
- `/relatorios` — gráficos e indicadores
- `/modo-tv` — modo televisão
- `/api/dashboard` — dados do dashboard
- `/api/tickets` — chamados ativos
- `/api/reports` — indicadores filtrados
- `/api/health` — saúde da aplicação
- `/api/esp32/event` — endpoint preparatório, sem integração física

## Regras dos indicadores
- **Tempo de parada:** calculado a partir de `downtime_started_at` e `downtime_ended_at`. Se a parada estiver ativa, o servidor calcula até o momento atual.
- **Tempo de atendimento:** calculado a partir de `assigned_at` até `resolved_at` (ou o momento atual, se ainda em atendimento).
- **MTTR:** média do tempo entre início do atendimento e encerramento, somente para chamados resolvidos com ambos os horários disponíveis.
- **MTBF:** estimativa dos intervalos entre aberturas consecutivas de falhas do mesmo equipamento. É exibido somente quando há ao menos dois registros para um equipamento. Para MTBF industrial rigoroso, integrar horas reais de operação e critérios de falha.
- Indicadores são filtrados pela data de abertura do chamado.

## Compatibilidade com a versão 1.0
A aplicação preserva as tabelas e colunas originais `equipment` e `ticket`. Ao iniciar, cria tabelas ausentes e adiciona apenas as novas colunas necessárias. A versão 3.0 mantém o caminho `instance/sime.db`, usado pelo Flask-SQLAlchemy na versão 1.0, para que o banco antigo seja reutilizado automaticamente. Faça uma cópia de segurança desse arquivo antes da primeira execução. **Observação:** o ZIP da versão 1.0 enviado para esta atualização não continha um arquivo de banco de dados. Se você já possui dados cadastrados na instalação antiga e vai extrair a versão 3.0 em outra pasta, copie o arquivo `instance/sime.db` da instalação antiga para a pasta `instance/` da nova instalação antes de iniciar.

## Limitações conhecidas
- Protótipo local com autenticação por sessão e permissões por perfil; use HTTPS, segredo forte e política de senhas antes de expor fora da rede local.
- As senhas iniciais são de demonstração e precisam ser alteradas.
- O modo TV exige sessão autenticada de manutenção ou administrador.
- Chart.js é carregado por CDN; os gráficos precisam de internet no navegador. As telas e dados principais funcionam localmente sem os gráficos caso o CDN esteja indisponível.
- Não há integração física com ESP32, CLP, sensores ou inversores nesta etapa.
- Não há sincronização multi-servidor; use uma única instância do servidor e um único arquivo SQLite.
- A categoria do equipamento é cadastro informativo; a categoria do chamado é registrada pelo operador.

## Backup
Antes de atualizar, pare o servidor e copie `sime.db` para um local seguro. Para restaurar, substitua o banco pelo backup com o servidor desligado.

## Aviso de uso
Este software é um protótipo acadêmico. Não substitui procedimentos oficiais de segurança, bloqueio e etiquetagem, autorização de trabalho ou sistemas industriais certificados.


## Atualização SIME 3.0 — mapa de equipamentos

## SIME 3.1 — central dinâmica

A tela Supervisório (PC) e o Modo TV priorizam ocorrências ativas em cards de alerta, ordenadas por criticidade. Cada alerta mostra TAG, nome, descrição, piso/setor, solicitante, responsável, estado e tempo de parada. A tela TV deixou de exibir o mosaico de equipamentos permanentemente; o mapa por piso é acessível sob demanda também pelo perfil Manutenção. O modo TV inclui botão de tela cheia e atualização automática de dados.


- Redesenho da tela Mapa por piso com navegação por piso e busca de TAG/nome/setor.
- Resumo visual de ativos normais, em manutenção e parados.
- Símbolos SVG vetoriais locais por família de TAG (válvulas, transporte, balança, motor, processo e genérico), sem dependência de imagens externas.
- Fichas continuam abrindo pelo clique no equipamento.
- Os símbolos são aproximações visuais: as TAGs do inventário não incluem fabricante/modelo/foto para identificação exata.

## SIME 3.2 — Mapa mímico SCADA (ilustrativo)

A página **Mapa por piso** foi redesenhada com um diagrama mímico industrial conceitual (SVG), no estilo de supervisórios/IHMs: silo, transportador, elevador, misturador, peletizadora, silo de produto final e utilidades, conectados por linhas coloridas. A tela inclui navegação por piso, busca e TAGs de equipamentos do inventário que abrem as fichas individuais.

**Limitação importante:** o desenho do processo é ilustrativo e não representa a planta real da fábrica nem a ligação física real entre as TAGs. Os indicadores de estado nas TAGs do inventário são calculados pelos chamados cadastrados no SIME. O diagrama SVG central é conceitual e não é alimentado individualmente pelos equipamentos reais. A integração física ESP32/CLP/sensores ainda não está implementada.

Para abrir o mapa, entre com perfil Administrador ou Manutenção e clique em **Mapa por piso**; escolha um piso, pesquise uma TAG e clique na TAG para abrir sua ficha.
