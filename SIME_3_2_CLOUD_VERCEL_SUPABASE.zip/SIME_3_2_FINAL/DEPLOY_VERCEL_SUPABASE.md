# SIME 3.2 — Deploy on Vercel + Supabase

This package keeps the Flask UI, equipment inventory, ticket system, user roles, plant views, and existing templates. In cloud mode it uses PostgreSQL through `DATABASE_URL` (or `POSTGRES_URL`) instead of a local SQLite file. The first cold start creates ORM tables and inserts the built-in equipment inventory. In cloud mode demo users are NOT seeded; the admin is created from `SIME_ADMIN_USERNAME` and `SIME_ADMIN_PASSWORD` environment variables.

## Before deploy

1. Create a Supabase project.
2. In Supabase, open **Connect** and choose a PostgreSQL connection URI. For serverless, prefer the pooler connection URL compatible with your region/runtime; replace its password placeholder. Use SSL.
3. Keep the database password private. Do not place it in a committed `.env`, source file, or browser-side JS.
4. Create a long random `SIME_SECRET` (for example, run `python -c "import secrets; print(secrets.token_urlsafe(48))"` locally).
5. Create a strong admin password for the first cloud account.


## Deploy to Vercel

1. Extract this ZIP and push its **contents** (the folder with `app.py`, `templates/`, and `static/`) to a private GitHub repository. Do not push real `.env` values.
2. In Vercel, **Add New → Project**, import that repository. Vercel should recognize the Flask app at `app.py`.
3. Open **Project → Settings → Environment Variables** and add:
   - `DATABASE_URL` = Supabase PostgreSQL connection URI (private server-side)
   - `SIME_SECRET` = generated random secret
   - `SIME_ADMIN_USERNAME` = chosen admin username
   - `SIME_ADMIN_PASSWORD` = strong admin password
4. Add variables to Production and Preview only as desired. Do not expose database URL as `NEXT_PUBLIC_*`.
5. Deploy. On initial cold start the app creates the ORM tables and seeds the equipment inventory. Log in using the admin credentials configured in the variables.
6. Once the deployment is live, immediately verify login, ticket creation, equipment pages, floor/map pages, reports, and admin user management. Inspect Vercel function logs if startup or DB connection fails.

## Database details

- Cloud uses SQLAlchemy + PostgreSQL (psycopg2), not SQLite.
- Schema is created from the existing ORM model definitions during application startup.
- Equipment inventory import is idempotent (only adds missing codes).
- Demo usernames/passwords (`admin12345`, etc.) are not provisioned in cloud mode.
- SQLite desktop mode is retained when `DATABASE_URL`/`POSTGRES_URL` are absent.
- Use Supabase database backups/export before upgrades. Do not treat `db.create_all()` as a migration tool for future column changes; add explicit migrations for later releases.

## Troubleshooting

- `RuntimeError: Defina SIME_SECRET`: add the secret environment variable in Vercel and redeploy.
- PostgreSQL connection error: confirm connection URI, DB password, SSL, and use a Supabase pooler URI suitable for serverless. Do not use a local `sqlite:///...` URL in Vercel.
- No admin user: check the spelling of `SIME_ADMIN_USERNAME` and `SIME_ADMIN_PASSWORD`, then redeploy. Admin bootstrap occurs at application import/startup only if no matching username exists yet. If the DB already contains that username, reset password through the SIME user admin UI after logging in as an existing admin.
- First deployment may take longer while tables and equipment inventory are initialized.

## Important current limitations

This is a cloud deployment adaptation, not a completed live deployment. No Supabase project has been connected and no Vercel deployment has been created from this package. Before exposing this system publicly, review security (CSRF protection, rate limits, administrator provisioning, backup/restore, and access controls) and run a complete functional test against the deployed PostgreSQL instance.
