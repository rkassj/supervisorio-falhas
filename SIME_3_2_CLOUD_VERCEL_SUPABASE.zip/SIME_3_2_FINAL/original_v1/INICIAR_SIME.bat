@echo off
cd /d "%~dp0"
echo =====================================
echo        SIME - SUPERVISORIO
echo =====================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python nao encontrado. Instale Python 3.10 ou superior.
  pause
  exit /b
)
if not exist .venv (
  python -m venv .venv
)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Sistema iniciando...
echo No computador: http://127.0.0.1:5000
echo Na rede local: use o IP deste computador + :5000
echo Para encerrar, pressione CTRL+C nesta janela.
python app.py
pause
