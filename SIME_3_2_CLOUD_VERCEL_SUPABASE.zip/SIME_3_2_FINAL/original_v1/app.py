from flask import Flask, render_template, request, redirect, url_for, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timezone
from sqlalchemy import func
import os

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///sime.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = os.environ.get("SIME_SECRET", "troque-esta-chave-em-producao")
db = SQLAlchemy(app)

STATUSES = ["Aberto", "Em atendimento", "Aguardando peça", "Resolvido"]
CATEGORIES = ["Elétrico", "Mecânico", "Automação", "Outro"]

class Equipment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    floor = db.Column(db.String(30), nullable=False)
    sector = db.Column(db.String(100), default="")
    category = db.Column(db.String(30), default="Outro")
    active = db.Column(db.Boolean, default=True)

class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id"), nullable=False)
    operator = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(30), nullable=False)
    status = db.Column(db.String(30), default="Aberto")
    stopped = db.Column(db.Boolean, default=True)
    opened_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    downtime_started_at = db.Column(db.DateTime, nullable=True)
    downtime_ended_at = db.Column(db.DateTime, nullable=True)
    assigned_to = db.Column(db.String(100), default="")
    assigned_at = db.Column(db.DateTime, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    solution = db.Column(db.Text, default="")
    equipment = db.relationship("Equipment", backref="tickets")

    def downtime_seconds(self):
        if not self.stopped or not self.downtime_started_at:
            return 0
        end = self.downtime_ended_at or datetime.utcnow()
        return max(0, int((end - self.downtime_started_at).total_seconds()))

    def service_seconds(self):
        if not self.assigned_at is not None:
            return 0
        end = self.resolved_at or datetime.utcnow()
        return max(0, int((end - self.assigned_at).total_seconds()))

    def as_dict(self):
        return {
            "id": self.id, "equipment": self.equipment.code,
            "equipment_name": self.equipment.name, "floor": self.equipment.floor,
            "sector": self.equipment.sector, "operator": self.operator,
            "description": self.description, "category": self.category,
            "status": self.status, "stopped": self.stopped,
            "opened_at": self.opened_at.isoformat() + "Z",
            "downtime_seconds": self.downtime_seconds(),
            "service_seconds": self.service_seconds(),
            "assigned_to": self.assigned_to or ""
        }

@app.template_filter("dt")
def format_dt(value):
    return value.strftime("%d/%m/%Y %H:%M") if value else "—"

@app.template_filter("duration")
def duration(seconds):
    seconds = int(seconds or 0)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    return (f"{days}d " if days else "") + f"{hours:02d}:{minutes:02d}:{secs:02d}"

@app.route("/")
def dashboard():
    tickets = Ticket.query.filter(Ticket.status != "Resolvido").order_by(Ticket.opened_at.asc()).all()
    total_open = len(tickets)
    in_progress = sum(t.status == "Em atendimento" for t in tickets)
    waiting = sum(t.status == "Aguardando peça" for t in tickets)
    stopped = sum(t.stopped and t.status != "Resolvido" for t in tickets)
    total_downtime = sum(t.downtime_seconds() for t in tickets)
    return render_template("dashboard.html", tickets=tickets, total_open=total_open,
                           in_progress=in_progress, waiting=waiting, stopped=stopped,
                           total_downtime=total_downtime)

@app.route("/novo", methods=["GET", "POST"])
def new_ticket():
    equipment = Equipment.query.filter_by(active=True).order_by(Equipment.floor, Equipment.code).all()
    if request.method == "POST":
        equipment_id = request.form.get("equipment_id", type=int)
        operator = request.form.get("operator", "").strip()
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "Outro")
        stopped = request.form.get("stopped") == "yes"
        eq = db.session.get(Equipment, equipment_id)
        if not eq or not operator or not description:
            return render_template("new_ticket.html", equipment=equipment, error="Preencha todos os campos obrigatórios.")
        now = datetime.utcnow()
        ticket = Ticket(equipment=eq, operator=operator, description=description,
                        category=category if category in CATEGORIES else "Outro",
                        stopped=stopped, opened_at=now,
                        downtime_started_at=now if stopped else None)
        db.session.add(ticket)
        db.session.commit()
        return redirect(url_for("dashboard"))
    return render_template("new_ticket.html", equipment=equipment, error=None)

@app.route("/chamado/<int:ticket_id>", methods=["GET", "POST"])
def manage_ticket(ticket_id):
    ticket = db.session.get(Ticket, ticket_id)
    if not ticket:
        abort(404)
    if request.method == "POST":
        action = request.form.get("action")
        if action == "assume":
            name = request.form.get("assigned_to", "").strip()
            if name:
                ticket.assigned_to = name
                ticket.assigned_at = ticket.assigned_at or datetime.utcnow()
                ticket.status = "Em atendimento"
        elif action == "waiting":
            ticket.status = "Aguardando peça"
        elif action == "resolve":
            ticket.solution = request.form.get("solution", "").strip()
            if ticket.stopped and ticket.downtime_started_at and not ticket.downtime_ended_at:
                ticket.downtime_ended_at = datetime.utcnow()
            ticket.stopped = False
            ticket.status = "Resolvido"
            ticket.resolved_at = datetime.utcnow()
        elif action == "reopen":
            ticket.status = "Aberto"
            ticket.resolved_at = None
            ticket.downtime_ended_at = None
            if ticket.stopped:
                ticket.downtime_started_at = datetime.utcnow()
        db.session.commit()
        return redirect(url_for("manage_ticket", ticket_id=ticket.id))
    return render_template("manage_ticket.html", ticket=ticket, statuses=STATUSES)

@app.route("/historico")
def history():
    tickets = Ticket.query.order_by(Ticket.opened_at.desc()).limit(300).all()
    return render_template("history.html", tickets=tickets)

@app.route("/equipamentos", methods=["GET", "POST"])
def equipment():
    if request.method == "POST":
        code = request.form.get("code", "").strip().upper()
        name = request.form.get("name", "").strip()
        floor = request.form.get("floor", "").strip()
        sector = request.form.get("sector", "").strip()
        category = request.form.get("category", "Outro")
        if code and name and floor and not Equipment.query.filter_by(code=code).first():
            db.session.add(Equipment(code=code, name=name, floor=floor, sector=sector, category=category))
            db.session.commit()
        return redirect(url_for("equipment"))
    items = Equipment.query.order_by(Equipment.floor, Equipment.code).all()
    return render_template("equipment.html", equipment=items)

@app.post("/equipamento/<int:equipment_id>/alternar")
def toggle_equipment(equipment_id):
    item = db.session.get(Equipment, equipment_id)
    if item:
        item.active = not item.active
        db.session.commit()
    return redirect(url_for("equipment"))

@app.route("/api/tickets")
def api_tickets():
    tickets = Ticket.query.filter(Ticket.status != "Resolvido").order_by(Ticket.opened_at.asc()).all()
    return jsonify([t.as_dict() for t in tickets])

@app.route("/api/esp32/event", methods=["POST"])
def esp32_event():
    # Endpoint preparado para futuras notificações do ESP32.
    data = request.get_json(silent=True) or {}
    event = data.get("event", "heartbeat")
    return jsonify({"ok": True, "received": event, "message": "Evento recebido. Integração de hardware pode ser expandida aqui."})

@app.route("/api/health")
def health():
    return jsonify({"status": "online", "application": "SIME"})

def seed():
    if Equipment.query.count() == 0:
        samples = [
            ("VG-01", "Válvula gaveta 01", "1º andar", "Transporte", "Mecânico"),
            ("VG-02", "Válvula gaveta 02", "2º andar", "Dosagem", "Elétrico"),
            ("M-01", "Motor 01", "2º andar", "Mistura", "Elétrico"),
            ("TR-01", "Transportador 01", "3º andar", "Transporte", "Mecânico"),
            ("EL-01", "Elevador 01", "4º andar", "Elevação", "Mecânico"),
            ("P-01", "Painel 01", "5º andar", "Comando", "Automação"),
            ("VG-03", "Válvula gaveta 03", "6º andar", "Expedição", "Elétrico"),
        ]
        for code, name, floor, sector, category in samples:
            db.session.add(Equipment(code=code, name=name, floor=floor, sector=sector, category=category))
        db.session.commit()

with app.app_context():
    db.create_all()
    seed()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
