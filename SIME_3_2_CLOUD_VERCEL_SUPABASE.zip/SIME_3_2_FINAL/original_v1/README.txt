SIME - SUPERVISORIO INTELIGENTE DE MANUTENCAO E EQUIPAMENTOS
Protótipo acadêmico SENAI

REQUISITOS
- Windows 10 ou 11
- Python 3.10 ou superior
- Computador conectado à rede Wi-Fi para acesso por outros dispositivos

COMO INICIAR
1. Extraia a pasta SIME_Supervisorio.
2. Dê dois cliques em INICIAR_SIME.bat.
3. Aguarde a instalação automática das bibliotecas.
4. Abra http://127.0.0.1:5000 no navegador.

ACESSO PELO CELULAR OU TV
1. Conecte computador, celular e TV à mesma rede Wi-Fi.
2. Descubra o IPv4 do computador:
   - Abra o Prompt de Comando.
   - Digite ipconfig.
   - Procure "Endereço IPv4" do adaptador Wi-Fi.
3. No celular/TV, acesse http://IP-DO-COMPUTADOR:5000
   Exemplo: http://192.168.0.25:5000
4. Se o Windows Firewall perguntar, permita acesso em rede privada.
   Não exponha este protótipo diretamente à internet.

FUNCIONALIDADES
- Dashboard com chamados ativos.
- Abertura de chamados.
- Cadastro de equipamentos.
- Atribuição de responsável.
- Status: aberto, em atendimento, aguardando peça e resolvido.
- Registro de solução.
- Histórico.
- Cronômetro de parada e de atendimento.
- API simples para futura integração ESP32.

DADOS DE DEMONSTRAÇÃO
O banco é criado automaticamente na primeira execução.
Os 7 equipamentos iniciais são exemplos fictícios. Substitua-os pelos códigos e
localizações reais autorizados pela Avenorte antes de qualquer apresentação externa.

ROTAS DE API
GET  /api/health
GET  /api/tickets
POST /api/esp32/event
Exemplo de JSON para POST /api/esp32/event:
{"event":"new_ticket","equipment":"VG-03"}

LIMITAÇÕES IMPORTANTES DO PROTÓTIPO
- A atualização da tela ocorre por recarga periódica; não é ainda um SCADA certificado.
- O ESP32 ainda não está conectado fisicamente; a rota de API está preparada para expansão.
- Não há autenticação de usuários nesta primeira versão.
- Não usar para comandar máquinas, circuitos de segurança ou equipamentos reais.
- Validar horários, regras de parada e requisitos com a equipe de manutenção.
- Antes de uso na fábrica, implementar login, permissões, backups, logs e segurança da rede.

ARQUIVOS
app.py                 Aplicação Flask e banco de dados
templates/             Telas HTML
static/style.css       Estilo visual
requirements.txt       Bibliotecas Python
INICIAR_SIME.bat       Inicialização no Windows
