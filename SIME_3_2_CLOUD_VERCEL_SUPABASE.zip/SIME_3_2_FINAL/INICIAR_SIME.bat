@echo off
title SIME 3.2 - Supervisório de Manutenção
cd /d "%~dp0"
echo ============================================
echo             SIME 3.2 - AVENORTE
echo ============================================
where py >nul 2>nul
if %errorlevel%==0 (set PY=py) else (set PY=python)
if not exist ".venv\Scripts\python.exe" (
  echo Criando ambiente virtual...
  %PY% -m venv .venv
)
call .venv\Scripts\activate.bat
echo Instalando/verificando dependencias...
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo ERRO ao instalar dependencias. Verifique sua conexao e instalacao do Python.
  pause
  exit /b 1
)
echo.
echo SIME iniciado. Acesse http://127.0.0.1:5000
echo Para encerrar, pressione CTRL+C nesta janela.
start "" http://127.0.0.1:5000
python app.py
pause
