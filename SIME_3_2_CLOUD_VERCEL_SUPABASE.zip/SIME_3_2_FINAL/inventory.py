"""Inventário inicial transcrito das anotações fornecidas pelo usuário.
Códigos repetidos em locais distintos recebem sufixo de localização para não colidir.
"""
# (piso, setor, categoria, conexões)
INVENTORY = {}
def add(floor, sector, codes, category='Outros'):
    for code in codes.split():
        code=code.strip().upper().replace('_','-')
        if code and code not in INVENTORY:
            INVENTORY[code]=(f'{floor}º piso',sector,category,'')

# 1º piso
add(1,'Área geral','EL-02 EL-10 BA-01 VG-09 RD-08 EL-03 EL-01 RD-07 RD-06 CX-1 CX-2 CX-3 CX-4 CX-5 CX-6 EL-11 RD-27 EL-04 EL-06 RD-38 EL-05 RD-14 RD-24 RD-13 EL-12')
add(1,'Área geral','BA-02 BA-16 BA-09 BALANCA-SAL')
# 2º piso
add(2,'Sala de comando','CCM PIMH-01 RD-09 RES-01 TRP-01 RES-02 TRP-02 BA-07')
add(2,'Linha SD / RTD','RES-03 TRP-03 SD-08 RTD-08 SD-13 RTD-13 SD-07 RTD-07 SD-11 RTD-11 SD-12 RTD-12 SD-02 RTD-02 SD-01 RTD-01 SD-10 RTD-10 SD-09 RTD-09 SD-05 RTD-05 SD-04 RTD-04 SD-06 RTD-06 VG-35 VG-62 VG-61')
add(2,'Acesso / área traseira','TH-09')
# 3º piso
add(3,'Peletizadora','RD-03 VG-03 CX-01 CX-02 CX-03 CX-04 CX-05 CX-06 VG-05 VG-06 VG-07 VG-08 VG-39 PIMH-01 PM-01 PEL-01 PEL-02 PEL-03')
# 4º piso
add(4,'Válvulas','MH-01 EC-03 TM-02 EC-02 TM-01 ROS-11 CON-03 LTC-02 ROS-08 CON-01 LTC-01')
# 5º piso
add(5,'Premix','EC-02-5P VR-02 VR-01 SD-08 SD-07 SD-13 SD-10 SD-12 SD-11 SD-09 SD-04 SD-05 SD-01 SD-06 SD-03 SD-02 MV-01 VG-52 VG-17 VD-11 VG-16 EC-02 CHU-01 SP-01 TH-05 TH-04 SP-02 TH-06 TH-07 SP-04 VG-72 SP-03 VG-71 EC-08 EC-01 ROS-10 CON-04 LTC-03 VD-25 VD-26 VD-27 VG-15')
# 6º piso — direita (tags repetidas com localização explícita)
add(6,'6º piso - lado direito','EL-10-6D RD-25 VG-33 VD-24 RD-04 EL-02-6D VD-04 VD-07 EL-01-6D VD-05 VD-06 RD-05 RD-26 VG-34 VG-36')
# 6º piso — esquerda
add(6,'6º piso - lado esquerdo','BO-19 BO-18 BO-17 PIBA-04 PIBA-11 PIBA-12 CX-07 EL-12-6E RD-22 EX-01 EL-05-6E VD-19 RD-19 RD-15 EL-04-6E RD-10 RD-36 VG-53 VG-55 VG-54 RD-16 VG-69 SP-4 VG-70 SP-3 VG-18 SP-2 VG-19 SP-1 EXA-01 EXA-02 RD-37 EXA-03')
# 6º piso — carregamento
add(6,'6º piso - carregamento','RD-15-6C VG-58 VG-57 RD-39 VG-73 VG-74 VG-75 VG-76 VG-77 VG-78 RD-31 VG-47 VG-48 VG-49 VG-50 SE-02 SE-03 SE-06 SE-07 RD-30 VG-43 VG-44 VG-45 VG-46 SE-01 SE-04 SE-05 SE-08 RD-19-6C VG-82-6C VG-21 VG-79 VG-80 VG-28 RD-20 VG-67 VG-22 VG-23 VG-24 SE-09 SE-11 SE-13 SE-15 VG-76-6C RD-21 VG-68 VG-25 VG-26 VG-27 SE-10 SE-12 SE-14 SE-16 VG-77-6C RD-28 VG-81 VG-82 VG-83 VG-84 VG-85 SE-17 SE-19 SE-21 SE-23 SE-25 VG-78-6C RD-29 VG-86 VG-87 VG-88 VG-89 VG-90 SE-18 SE-20 SE-22 SE-24 SE-26')

# Ligações literais extraídas das setas fornecidas.
EDGES = [
('BA-01','VG-09'),('VG-09','RD-08'),('RD-08','EL-03'),('EL-01','RD-07'),('RD-07','RD-06'),('RD-06','CX-1'),('RD-06','CX-2'),('RD-06','CX-3'),('RD-06','CX-4'),('RD-06','CX-5'),('RD-06','CX-6'),('EL-11','RD-27'),('EL-06','RD-38'),('EL-05','RD-14'),('RD-14','RD-24'),('RD-14','RD-13'),('EL-10-6D','RD-25'),('RD-25','VG-33'),('VG-33','VD-24'),('VD-24','RD-04'),('EL-02-6D','VD-04'),('VD-04','VD-07'),('EL-01-6D','VD-05'),('VD-05','VD-06'),('VD-06','RD-05'),('RD-25','RD-26'),('RD-26','VG-34'),('RD-26','VG-36'),
('PIMH-01','RD-09'),('RES-01','TRP-01'),('RES-02','TRP-02'),('RES-03','TRP-03'),('SD-08','RTD-08'),('SD-13','RTD-13'),('SD-07','RTD-07'),('SD-11','RTD-11'),('SD-12','RTD-12'),('SD-02','RTD-02'),('SD-01','RTD-01'),('SD-10','RTD-10'),('SD-09','RTD-09'),('SD-05','RTD-05'),('SD-04','RTD-04'),('SD-06','RTD-06'),
('RD-03','VG-03'),('RD-03','VG-05'),('RD-03','VG-06'),('RD-03','VG-07'),('RD-03','VG-08'),('RD-03','VG-39'),('VG-03','CX-01'),('VG-05','CX-02'),('VG-06','CX-03'),('VG-07','CX-04'),('VG-08','CX-05'),('VG-39','CX-06'),
('EC-03','TM-02'),('EC-02','TM-01'),('ROS-11','CON-03'),('CON-03','LTC-02'),('ROS-08','CON-01'),('CON-01','LTC-01'),
('VR-02','SD-08'),('VR-02','SD-07'),('VR-02','SD-13'),('VR-02','SD-10'),('VR-02','SD-12'),('VR-02','SD-11'),('VR-02','SD-09'),('VR-01','SD-04'),('VR-01','SD-05'),('VR-01','SD-01'),('VR-01','SD-06'),('VR-01','SD-03'),('VR-01','SD-02'),('MV-01','VG-52'),('VG-17','VD-11'),('EC-02-5P','CHU-01'),('SP-01','TH-05'),('SP-01','TH-04'),('SP-02','TH-06'),('SP-02','TH-07'),('SP-04','VG-72'),('SP-03','VG-71'),('ROS-10','CON-04'),('CON-04','LTC-03'),
('EL-12-6E','RD-22'),('EL-05-6E','VD-19'),('VD-19','RD-19'),('EL-04-6E','RD-10'),('EL-04-6E','RD-36'),('RD-10','VG-53'),('RD-10','VG-55'),('VG-55','RD-15'),('RD-10','VG-54'),('VG-54','RD-16'),('RD-36','RD-37'),('RD-37','VG-69'),('VG-69','SP-4'),('RD-37','VG-70'),('VG-70','SP-3'),('RD-16','VG-18'),('VG-18','SP-2'),('RD-16','VG-19'),('VG-19','SP-1'),
('RD-15-6C','VG-58'),('RD-15-6C','VG-57'),('RD-39','VG-73'),('RD-39','VG-74'),('RD-39','VG-75'),('RD-39','VG-76'),('RD-39','VG-77'),('RD-39','VG-78'),('VG-57','RD-31'),('VG-73','RD-31'),('RD-31','VG-47'),('RD-31','VG-48'),('RD-31','VG-49'),('RD-31','VG-50'),('VG-47','SE-02'),('VG-48','SE-03'),('VG-49','SE-06'),('VG-50','SE-07'),('VG-58','RD-30'),('VG-74','RD-30'),('RD-30','VG-43'),('RD-30','VG-44'),('RD-30','VG-45'),('RD-30','VG-46'),('VG-43','SE-01'),('VG-44','SE-04'),('VG-45','SE-05'),('VG-46','SE-08'),('RD-19-6C','VG-82-6C'),('RD-19-6C','VG-21'),('RD-19-6C','VG-79'),('RD-19-6C','VG-80'),('VG-28','RD-20'),('VG-75','RD-20'),('RD-20','VG-67'),('RD-20','VG-22'),('RD-20','VG-23'),('RD-20','VG-24'),('VG-67','SE-09'),('VG-22','SE-11'),('VG-23','SE-13'),('VG-24','SE-15'),('VG-21','RD-21'),('VG-76','RD-21'),('RD-21','VG-68'),('RD-21','VG-25'),('RD-21','VG-26'),('RD-21','VG-27'),('VG-68','SE-10'),('VG-25','SE-12'),('VG-26','SE-14'),('VG-27','SE-16'),('VG-79','RD-28'),('VG-77','RD-28'),('RD-28','VG-81'),('RD-28','VG-82'),('RD-28','VG-83'),('RD-28','VG-84'),('RD-28','VG-85'),('VG-81','SE-17'),('VG-82','SE-19'),('VG-83','SE-21'),('VG-84','SE-23'),('VG-85','SE-25'),('VG-80','RD-29'),('VG-78','RD-29'),('RD-29','VG-86'),('RD-29','VG-87'),('RD-29','VG-88'),('RD-29','VG-89'),('RD-29','VG-90'),('VG-86','SE-18'),('VG-87','SE-20'),('VG-88','SE-22'),('VG-89','SE-24'),('VG-90','SE-26')]

EDGES += [('RTD-08','BA-07'),('RTD-10','BA-07'),('RTD-11','BA-07'),('RTD-12','BA-07'),('RTD-13','BA-07'),('RTD-07','BA-01'),('RTD-09','BA-01'),('RTD-02','BA-01'),('RTD-01','BA-01'),('RTD-05','BA-01'),('RTD-04','BA-01'),('RTD-06','BA-01')]
