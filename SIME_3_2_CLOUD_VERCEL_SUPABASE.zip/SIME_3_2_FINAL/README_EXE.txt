SIME 3.2 - PACOTE PARA WINDOWS

COMO GERAR O EXECUTAVEL
1. Em um computador Windows, instale Python 3.10 ou mais novo (marque Add Python to PATH durante a instalacao).
2. Extraia esta pasta inteira.
3. Execute BUILD_SIME_EXE.bat.
4. O script instala as dependencias e compila o SIME.
5. O executavel sera criado em dist\SIME_3_2.exe.

COMO USAR O EXECUTAVEL
- Copie SIME_3_2.exe para uma pasta no computador.
- Execute com duplo clique. O navegador abrirá no SIME local.
- O banco de dados será armazenado na pasta SIME_data, ao lado do executavel.
- Não apague a pasta SIME_data se quiser manter usuários, equipamentos e chamados.

NOTAS
- O executavel precisa ser compilado em Windows. O pacote de desenvolvimento inclui o script automatizado para isso.
- Esta versão é local, para um computador. Para vários computadores compartilharem dados, será necessária uma instalação servidor/rede.
- Ao compilar, Windows Defender/SmartScreen pode exibir aviso para EXE não assinado. Isso é comum em programas próprios sem assinatura digital.

Tema atualizado SIME: azul-marinho, cinza e laranja. Ícone do executável: static/img/sime-icon.ico.
