@echo off
title Testes SIME 3.2
cd /d "%~dp0"
if not exist ".venv\Scripts\activate.bat" (
  echo Execute INICIAR_SIME.bat primeiro para instalar as dependencias.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m unittest discover -s tests -v
pause
