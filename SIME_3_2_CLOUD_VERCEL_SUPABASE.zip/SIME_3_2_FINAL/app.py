from flask import Flask, render_template, request, redirect, url_for, jsonify, abort, flash, session, g
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from sqlalchemy import func, inspect, text
from sqlalchemy.exc import IntegrityError
from pathlib import Path
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import os
import sys
import threading
import webbrowser

BASE_DIR = Path(__file__).resolve().parent
# Cloud deploy: DATABASE_URL points to Supabase PostgreSQL. Desktop keeps SQLite.
DATABASE_URL = os.environ.get("DATABASE_URL", os.environ.get("POSTGRES_URL", "")).strip()
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)
if DATABASE_URL.startswith("postgresql://") and "sslmode=" not in DATABASE_URL:
    DATABASE_URL += ("&" if "?" in DATABASE_URL else "?") + "sslmode=require"
CLOUD_MODE = bool(DATABASE_URL)
if not CLOUD_MODE:
    if getattr(sys, "frozen", False):
        INSTANCE_DIR = Path(sys.executable).resolve().parent / "SIME_data"
    else:
        INSTANCE_DIR = BASE_DIR / "instance"
    INSTANCE_DIR.mkdir(exist_ok=True)
    DATABASE_URL = f"sqlite:///{(INSTANCE_DIR / 'sime.db').as_posix()}"
app = Flask(__name__)
app.config.update(
    SQLALCHEMY_DATABASE_URI=DATABASE_URL,
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SQLALCHEMY_ENGINE_OPTIONS={"pool_pre_ping": True, **({"pool_recycle": 300, "pool_size": 1, "max_overflow": 0} if CLOUD_MODE else {})},
    SECRET_KEY=os.environ.get("SIME_SECRET", "local-only-unsafe-secret-change-this"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=CLOUD_MODE,
)
if CLOUD_MODE and not os.environ.get("SIME_SECRET"):
    raise RuntimeError("Defina SIME_SECRET nas variáveis de ambiente da Vercel.")

db = SQLAlchemy(app)

FLOORS = [f"{n}º piso" for n in range(1, 7)]
CATEGORIES = ["Elétrica", "Mecânica", "Automação", "Outros"]
STATUSES = ["Aberto", "Em atendimento", "Aguardando peças", "Resolvido"]
PRIORITIES = ["Baixa", "Normal", "Alta", "Crítica"]
ACTIVE_STATUSES = ("Aberto", "Em atendimento", "Aguardando peças")


def utcnow():
    return datetime.utcnow()


def parse_dt(value):
    if not value:
        return None
    return datetime.fromisoformat(value)


class Equipment(db.Model):
    __tablename__ = "equipment"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    floor = db.Column(db.String(30), nullable=False)
    sector = db.Column(db.String(100), default="")
    category = db.Column(db.String(30), default="Outros")
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)
    connections = db.Column(db.Text, default="")

    @property
    def active_tickets(self):
        return [t for t in self.tickets if t.status != "Resolvido"]

    @property
    def visual_status(self):
        active = self.active_tickets
        if not active:
            return "normal"
        if any(t.stopped for t in active):
            return "stopped"
        return "maintenance"

    @property
    def current_ticket(self):
        active = self.active_tickets
        return sorted(active, key=lambda t: (t.stopped, t.opened_at), reverse=True)[0] if active else None

    def downtime_total_seconds(self):
        return sum(t.downtime_seconds() for t in self.tickets)


class Ticket(db.Model):
    __tablename__ = "ticket"
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id"), nullable=False)
    operator = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(30), nullable=False)
    status = db.Column(db.String(30), default="Aberto", nullable=False)
    stopped = db.Column(db.Boolean, default=True, nullable=False)
    opened_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    downtime_started_at = db.Column(db.DateTime)
    downtime_ended_at = db.Column(db.DateTime)
    assigned_to = db.Column(db.String(100), default="")
    assigned_at = db.Column(db.DateTime)
    resolved_at = db.Column(db.DateTime)
    solution = db.Column(db.Text, default="")
    priority = db.Column(db.String(20), default="Normal", nullable=False)
    diagnosis = db.Column(db.Text, default="")
    parts_used = db.Column(db.Text, default="")
    cause = db.Column(db.Text, default="")
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow)
    equipment = db.relationship("Equipment", backref=db.backref("tickets", lazy="select"))

    def downtime_seconds(self):
        if not self.downtime_started_at:
            return 0
        end = self.downtime_ended_at or utcnow()
        return max(0, int((end - self.downtime_started_at).total_seconds()))

    def service_seconds(self):
        if not self.assigned_at:
            return 0
        end = self.resolved_at or utcnow()
        return max(0, int((end - self.assigned_at).total_seconds()))

    def as_dict(self):
        return {
            "id": self.id, "equipment_id": self.equipment_id,
            "equipment": self.equipment.code, "equipment_name": self.equipment.name,
            "floor": self.equipment.floor, "sector": self.equipment.sector or "",
            "operator": self.operator, "description": self.description, "cause": self.cause or "",
            "category": self.category, "status": self.status, "stopped": bool(self.stopped),
            "priority": self.priority, "opened_at": self.opened_at.isoformat(),
            "downtime_seconds": self.downtime_seconds(),
            "service_seconds": self.service_seconds(),
            "assigned_to": self.assigned_to or "",
        }


class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(60), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin, maintenance, production
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


def migrate_schema():
    """Additive SQLite migration; existing rows and columns are retained."""
    db.create_all()
    if CLOUD_MODE:
        # Supabase deployment is initialized from ORM models; SQLite ALTER migrations are local-only.
        db.session.commit()
        return
    additions = {
        "equipment": {
            "created_at": "DATETIME",
            "updated_at": "DATETIME",
            "connections": "TEXT DEFAULT ''",
        },
        "ticket": {
            "priority": "VARCHAR(20) NOT NULL DEFAULT 'Normal'",
            "diagnosis": "TEXT DEFAULT ''",
            "parts_used": "TEXT DEFAULT ''",
            "cause": "TEXT DEFAULT ''",
            "updated_at": "DATETIME",
        },
    }
    inspector = inspect(db.engine)
    for table, columns in additions.items():
        existing = {c["name"] for c in inspector.get_columns(table)}
        for column, definition in columns.items():
            if column not in existing:
                db.session.execute(text(f'ALTER TABLE "{table}" ADD COLUMN "{column}" {definition}'))
    # Normalize floor labels used by v2.0 while preserving the existing assets.
    for n in range(1, 7):
        db.session.execute(text('UPDATE equipment SET floor = :new WHERE floor = :old'), {"new": f"{n}º piso", "old": f"{n}º andar"})
    db.session.commit()
    # Equipment is imported from the provided inventory below; no synthetic sample assets.


@app.template_filter("dt")
def format_dt(value):
    return value.strftime("%d/%m/%Y %H:%M") if value else "—"


@app.template_filter("duration")
def duration(seconds):
    seconds = int(seconds or 0)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    return (f"{days}d " if days else "") + f"{hours:02d}:{minutes:02d}:{secs:02d}"


def icon_family(code):
    tag = (code or "").upper()
    if tag.startswith(("VG", "VD")): return "valve"
    if tag.startswith(("SD", "RTD", "CON", "LTC")): return "conveyor"
    if tag.startswith(("BA", "BALANCA")): return "scale"
    if tag.startswith(("EC", "TM", "EL", "EX", "EXA")): return "motor"
    if tag.startswith(("SP", "CHU", "TH", "VR", "MV")): return "process"
    return "machine"


def dashboard_data():
    active = Ticket.query.filter(Ticket.status != "Resolvido").all()
    recent = Ticket.query.order_by(Ticket.opened_at.desc()).limit(8).all()
    equipment = Equipment.query.filter_by(active=True).order_by(Equipment.floor, Equipment.code).all()
    return active, recent, equipment


@app.route("/")
def dashboard():
    if g.user.role == "production":
        return redirect(url_for("new_ticket"))
    active, recent, equipment = dashboard_data()
    return render_template(
        "dashboard.html", total_open=len(active),
        in_progress=sum(t.status == "Em atendimento" for t in active),
        waiting=sum(t.status in ("Aberto", "Aguardando peças", "Aguardando peça") for t in active),
        stopped=sum(t.stopped for t in active),
        total_downtime=sum(t.downtime_seconds() for t in active),
        recent=recent, floors=FLOORS, equipment=equipment, active_tickets=active,
    )


@app.route("/novo", methods=["GET", "POST"])
def new_ticket():
    equipment = Equipment.query.filter_by(active=True).order_by(Equipment.floor, Equipment.code).all()
    if request.method == "POST":
        eq = db.session.get(Equipment, request.form.get("equipment_id", type=int))
        operator = g.user.full_name if g.user.role == "production" else request.form.get("operator", "").strip()
        description = request.form.get("description", "").strip()
        cause = request.form.get("cause", "").strip()
        category = request.form.get("category", "Outros")
        priority = request.form.get("priority", "Normal")
        stopped = request.form.get("stopped") == "yes"
        if not eq or not eq.active or not operator or not description or not cause:
            flash("Confira os campos obrigatórios e selecione um equipamento ativo.", "error")
        elif category not in CATEGORIES or priority not in PRIORITIES:
            flash("Categoria ou prioridade inválida.", "error")
        else:
            now = utcnow()
            ticket = Ticket(
                equipment=eq, operator=operator, description=description,
                category=category, priority=priority, stopped=stopped, cause=cause,
                status="Aberto", opened_at=now,
                downtime_started_at=now if stopped else None,
            )
            db.session.add(ticket)
            db.session.commit()
            flash(f"Chamado #{ticket.id} registrado com sucesso.", "success")
            return redirect(url_for("my_tickets") if g.user.role == "production" else url_for("dashboard"))
    return render_template("new_ticket.html", equipment=equipment, categories=CATEGORIES, priorities=PRIORITIES)


@app.route("/meus-chamados")
def my_tickets():
    tickets = Ticket.query.filter_by(operator=g.user.full_name).order_by(Ticket.opened_at.desc()).limit(200).all()
    return render_template("my_tickets.html", tickets=tickets)


@app.route("/chamado/<int:ticket_id>", methods=["GET", "POST"])
def manage_ticket(ticket_id):
    ticket = db.session.get(Ticket, ticket_id)
    if not ticket:
        abort(404)
    if request.method == "POST":
        action = request.form.get("action")
        now = utcnow()
        if ticket.status == "Resolvido" and action != "reopen":
            flash("Chamado resolvido. Reabra-o antes de alterar o atendimento.", "error")
        elif action == "assume":
            name = request.form.get("assigned_to", "").strip()
            if not name:
                flash("Informe o responsável.", "error")
            else:
                ticket.assigned_to = name
                ticket.assigned_at = ticket.assigned_at or now
                ticket.status = "Em atendimento"
        elif action == "waiting":
            ticket.status = "Aguardando peças"
        elif action == "update":
            ticket.diagnosis = request.form.get("diagnosis", "").strip()
            ticket.parts_used = request.form.get("parts_used", "").strip()
        elif action == "resolve":
            ticket.diagnosis = request.form.get("diagnosis", ticket.diagnosis).strip()
            ticket.solution = request.form.get("solution", "").strip()
            ticket.parts_used = request.form.get("parts_used", ticket.parts_used).strip()
            if not ticket.solution:
                flash("Registre a solução aplicada antes de encerrar.", "error")
                return redirect(url_for("manage_ticket", ticket_id=ticket.id))
            if ticket.downtime_started_at and not ticket.downtime_ended_at:
                ticket.downtime_ended_at = now
            # Keep the original stopped flag for a faithful reopen; the resolved
            # status removes it from the live equipment state, and downtime is closed.
            ticket.status = "Resolvido"
            ticket.resolved_at = now
        elif action == "reopen":
            ticket.status = "Aberto"
            ticket.resolved_at = None
            ticket.downtime_ended_at = None
            if ticket.stopped:
                ticket.downtime_started_at = now
        else:
            flash("Ação não reconhecida.", "error")
        db.session.commit()
        return redirect(url_for("manage_ticket", ticket_id=ticket.id))
    return render_template("manage_ticket.html", ticket=ticket)


@app.route("/historico")
def history():
    tickets = Ticket.query.order_by(Ticket.opened_at.desc()).limit(500).all()
    return render_template("history.html", tickets=tickets)


@app.route("/equipamentos", methods=["GET", "POST"])
def equipment():
    if request.method == "POST":
        code = request.form.get("code", "").strip().upper()
        name = request.form.get("name", "").strip()
        floor = request.form.get("floor", "").strip()
        sector = request.form.get("sector", "").strip()
        category = request.form.get("category", "Outros")
        if not code or not name or floor not in FLOORS or category not in CATEGORIES:
            flash("Preencha os campos corretamente.", "error")
        elif Equipment.query.filter(func.upper(Equipment.code) == code).first():
            flash("Já existe um equipamento com esse código.", "error")
        else:
            db.session.add(Equipment(code=code, name=name, floor=floor, sector=sector, category=category))
            db.session.commit()
            flash("Equipamento cadastrado.", "success")
            return redirect(url_for("equipment"))
    items = Equipment.query.order_by(Equipment.floor, Equipment.code).all()
    return render_template("equipment.html", equipment=items, floors=FLOORS, categories=CATEGORIES)


@app.route("/equipamento/<int:equipment_id>/editar", methods=["GET", "POST"])
def edit_equipment(equipment_id):
    item = db.session.get(Equipment, equipment_id)
    if not item:
        abort(404)
    if request.method == "POST":
        item.code = request.form.get("code", "").strip().upper()
        item.name = request.form.get("name", "").strip()
        item.floor = request.form.get("floor", "").strip()
        item.sector = request.form.get("sector", "").strip()
        item.category = request.form.get("category", "Outros")
        if not item.code or not item.name or item.floor not in FLOORS or item.category not in CATEGORIES:
            flash("Dados inválidos.", "error")
        else:
            try:
                db.session.commit()
                flash("Equipamento atualizado.", "success")
                return redirect(url_for("equipment"))
            except IntegrityError:
                db.session.rollback()
                flash("Já existe outro equipamento com esse código.", "error")
    return render_template("edit_equipment.html", item=item, floors=FLOORS, categories=CATEGORIES)


@app.post("/equipamento/<int:equipment_id>/alternar")
def toggle_equipment(equipment_id):
    item = db.session.get(Equipment, equipment_id)
    if not item:
        abort(404)
    if item.active and item.active_tickets:
        flash("Não é possível desativar: existem chamados ativos para este equipamento.", "error")
    else:
        item.active = not item.active
        db.session.commit()
        flash("Situação do equipamento alterada.", "success")
    return redirect(url_for("equipment"))


@app.route("/equipamento/<int:equipment_id>")
def equipment_detail(equipment_id):
    item = db.session.get(Equipment, equipment_id)
    if not item:
        abort(404)
    tickets = Ticket.query.filter_by(equipment_id=item.id).order_by(Ticket.opened_at.desc()).all()
    return render_template("equipment_detail.html", item=item, tickets=tickets)


@app.route("/relatorios")
def reports():
    return render_template("reports.html", floors=FLOORS, categories=CATEGORIES)


@app.route("/modo-tv")
def tv_mode():
    return render_template("tv.html", floors=FLOORS)


@app.route("/admin/usuarios", methods=["GET", "POST"])
def users_admin():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        full_name = request.form.get("full_name", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "production")
        if not username or not full_name or len(password) < 8 or role not in ("admin", "maintenance", "production"):
            flash("Informe usuário, nome, perfil e senha com pelo menos 8 caracteres.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Este usuário já existe.", "error")
        else:
            user = User(username=username, full_name=full_name, role=role)
            user.set_password(password)
            db.session.add(user); db.session.commit()
            flash("Usuário criado.", "success")
            return redirect(url_for("users_admin"))
    users = User.query.order_by(User.role, User.full_name).all()
    return render_template("users.html", users=users)

@app.post("/admin/usuarios/<int:user_id>/alternar")
def toggle_user(user_id):
    user = db.session.get(User, user_id)
    if not user: abort(404)
    if user.id == g.user.id:
        flash("Você não pode desativar sua própria conta.", "error")
    elif user.role == "admin" and User.query.filter_by(role="admin", active=True).count() <= 1:
        flash("Mantenha pelo menos um administrador ativo.", "error")
    else:
        user.active = not user.active; db.session.commit()
        flash("Acesso do usuário atualizado.", "success")
    return redirect(url_for("users_admin"))

@app.post("/admin/usuarios/<int:user_id>/reset-senha")
def reset_user_password(user_id):
    user = db.session.get(User, user_id)
    if not user:
        abort(404)
    password = request.form.get("password", "")
    if len(password) < 8:
        flash("A nova senha precisa ter pelo menos 8 caracteres.", "error")
    else:
        user.set_password(password)
        db.session.commit()
        flash(f"Senha do usuário {user.username} redefinida.", "success")
    return redirect(url_for("users_admin"))

@app.post("/admin/usuarios/<int:user_id>/excluir")
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        abort(404)
    if user.id == g.user.id:
        flash("Você não pode excluir sua própria conta.", "error")
    elif user.role == "admin" and User.query.filter_by(role="admin").count() <= 1:
        flash("Não é permitido excluir o último administrador.", "error")
    else:
        username = user.username
        db.session.delete(user)
        db.session.commit()
        flash(f"Usuário {username} excluído permanentemente.", "success")
    return redirect(url_for("users_admin"))

@app.route("/planta")
def plant_map():
    equipment = Equipment.query.filter_by(active=True).order_by(Equipment.floor, Equipment.sector, Equipment.code).all()
    grouped = {floor: {} for floor in FLOORS}
    # Ícones são famílias visuais aproximadas baseadas no prefixo do TAG.
    # Não substituem a identificação física/modelo do equipamento.
    def icon_family(code):
        tag = (code or "").upper()
        if tag.startswith(("VG", "VD")): return "valve"
        if tag.startswith(("SD", "RTD", "CON", "LTC")): return "conveyor"
        if tag.startswith(("BA", "BALANCA")): return "scale"
        if tag.startswith(("EC", "TM", "EL", "EX", "EXA")): return "motor"
        if tag.startswith(("SP", "CHU", "TH", "VR", "MV")): return "process"
        return "machine"
    for item in equipment:
        grouped.setdefault(item.floor, {}).setdefault(item.sector or "Área não definida", []).append(item)
        item.sime_icon = icon_family(item.code)
        item.sime_status = item.visual_status
        item.sime_ticket = item.current_ticket
    floor_stats = {}
    for floor in FLOORS:
        items = [e for e in equipment if e.floor == floor]
        floor_stats[floor] = {
            "total": len(items),
            "stopped": sum(e.visual_status == "stopped" for e in items),
            "maintenance": sum(e.visual_status == "maintenance" for e in items),
            "normal": sum(e.visual_status == "normal" for e in items),
        }
    return render_template("plant.html", grouped=grouped, floors=FLOORS, total=len(equipment), floor_stats=floor_stats)


@app.route("/api/dashboard")
def api_dashboard():
    active, recent, equipment = dashboard_data()
    payload = {
        "metrics": {
            "total_open": len(active),
            "in_progress": sum(t.status == "Em atendimento" for t in active),
            "waiting": sum(t.status in ("Aberto", "Aguardando peças", "Aguardando peça") for t in active),
            "stopped": sum(t.stopped for t in active),
            "total_downtime": sum(t.downtime_seconds() for t in active),
        },
        "tickets": [t.as_dict() for t in active],
        "recent": [t.as_dict() for t in recent],
        "equipment": [{
            "id": e.id, "code": e.code, "name": e.name, "floor": e.floor,
            "sector": e.sector or "", "category": e.category,
            "status": e.visual_status, "icon_family": icon_family(e.code),
            "ticket_id": e.current_ticket.id if e.current_ticket else None,
            "ticket_status": e.current_ticket.status if e.current_ticket else None,
        } for e in equipment],
        "server_time": utcnow().isoformat(),
    }
    return jsonify(payload)


@app.route("/api/reports")
def api_reports():
    start = parse_dt(request.args.get("start"))
    end = parse_dt(request.args.get("end"))
    floor = request.args.get("floor", "")
    category = request.args.get("category", "")
    query = Ticket.query.join(Equipment)
    if start:
        query = query.filter(Ticket.opened_at >= start)
    if end:
        query = query.filter(Ticket.opened_at < end + timedelta(days=1))
    if floor in FLOORS:
        query = query.filter(Equipment.floor == floor)
    if category in CATEGORIES:
        query = query.filter(Ticket.category == category)
    tickets = query.order_by(Ticket.opened_at.asc()).all()

    by_floor = {f: 0 for f in FLOORS}
    by_category = {c: 0 for c in CATEGORIES}
    by_equipment = {}
    downtime = {}
    resolved = []
    for t in tickets:
        by_floor[t.equipment.floor] += 1
        by_category[t.category] = by_category.get(t.category, 0) + 1
        key = t.equipment.code
        by_equipment[key] = by_equipment.get(key, 0) + 1
        downtime[key] = downtime.get(key, 0) + t.downtime_seconds()
        if t.resolved_at and t.assigned_at and t.resolved_at >= t.assigned_at:
            resolved.append((t.resolved_at - t.assigned_at).total_seconds())
    mttr = sum(resolved) / len(resolved) if resolved else None

    # MTBF is only calculated for equipment with at least two recorded failures.
    intervals = []
    by_eq = {}
    for t in tickets:
        by_eq.setdefault(t.equipment_id, []).append(t)
    for eq_tickets in by_eq.values():
        ordered = sorted(eq_tickets, key=lambda x: x.opened_at)
        if len(ordered) >= 2:
            intervals.extend((ordered[i].opened_at - ordered[i-1].opened_at).total_seconds()
                             for i in range(1, len(ordered)))
    mtbf = sum(intervals) / len(intervals) if intervals else None

    return jsonify({
        "total": len(tickets), "by_floor": by_floor, "by_category": by_category,
        "top_equipment": sorted(by_equipment.items(), key=lambda x: x[1], reverse=True)[:10],
        "downtime": sorted(downtime.items(), key=lambda x: x[1], reverse=True)[:10],
        "mttr_seconds": mttr, "mtbf_seconds": mtbf,
        "mttr_samples": len(resolved), "mtbf_intervals": len(intervals),
    })


@app.route("/api/tickets")
def api_tickets():
    tickets = Ticket.query.filter(Ticket.status != "Resolvido").order_by(Ticket.opened_at.asc()).all()
    return jsonify([t.as_dict() for t in tickets])


@app.route("/api/esp32/event", methods=["POST"])
def esp32_event():
    data = request.get_json(silent=True) or {}
    return jsonify({
        "ok": True, "received": data.get("event", "heartbeat"),
        "message": "Endpoint preparado; integração física não habilitada nesta versão."
    })


@app.route("/api/health")
def health():
    return jsonify({"status": "online", "application": "SIME", "version": "3.2"})


@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="Seu perfil não possui permissão para acessar esta área."), 403


@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="Registro ou página não encontrado."), 404


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username, active=True).first()
        if user and user.check_password(password):
            session.clear(); session["user_id"] = user.id
            return redirect(url_for("dashboard"))
        flash("Usuário ou senha inválidos.", "error")
    return render_template("login.html")

@app.route("/perfil/senha", methods=["GET", "POST"])
def change_password():
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        if not g.user.check_password(current):
            flash("A senha atual não confere.", "error")
        elif len(new) < 8:
            flash("A nova senha precisa ter pelo menos 8 caracteres.", "error")
        elif new != confirm:
            flash("A confirmação não corresponde à nova senha.", "error")
        else:
            g.user.set_password(new); db.session.commit()
            flash("Senha alterada com sucesso.", "success")
            return redirect(url_for("dashboard"))
    return render_template("change_password.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.before_request
def load_user_and_authorize():
    if request.endpoint in ("login", "static"):
        return
    user_id = session.get("user_id")
    g.user = db.session.get(User, user_id) if user_id else None
    if not g.user or not g.user.active:
        session.clear()
        return redirect(url_for("login", next=request.path))
    role = g.user.role
    endpoint = request.endpoint
    admin_only = {"users_admin", "toggle_user", "delete_user", "reset_user_password", "equipment", "edit_equipment", "toggle_equipment"}
    maintenance_only = {"manage_ticket", "equipment_detail", "history", "reports", "tv_mode", "api_dashboard", "api_reports", "api_tickets"}
    production_only = {"my_tickets"}
    if role != "admin" and endpoint in admin_only:
        abort(403)
    if role == "production" and endpoint in maintenance_only:
        abort(403)
    if role == "maintenance" and endpoint == "new_ticket":
        abort(403)
    if role == "maintenance" and endpoint in production_only:
        abort(403)

with app.app_context():
    migrate_schema()
    # Local mode seeds demo accounts. Cloud mode creates only an admin from environment variables.
    if not CLOUD_MODE:
        defaults = [("admin", "Administrador SIME", "admin12345", "admin"),
                    ("manutencao", "Equipe de Manutenção", "manut12345", "maintenance"),
                    ("producao", "Operador de Produção", "prod12345", "production")]
    else:
        defaults = []
        cloud_admin = os.environ.get("SIME_ADMIN_USERNAME", "").strip().lower()
        cloud_password = os.environ.get("SIME_ADMIN_PASSWORD", "")
        if cloud_admin and cloud_password and not User.query.filter_by(username=cloud_admin).first():
            defaults.append((cloud_admin, "Administrador SIME", cloud_password, "admin"))
    for username, full_name, password, role in defaults:
        if not User.query.filter_by(username=username).first():
            u = User(username=username, full_name=full_name, role=role); u.set_password(password); db.session.add(u)
    db.session.commit()
    # Importa inventário informado pelo usuário, sem sobrescrever cadastros existentes.
    try:
        from inventory import INVENTORY, EDGES
        for code, (floor, sector, category, _) in INVENTORY.items():
            if not Equipment.query.filter_by(code=code).first():
                db.session.add(Equipment(code=code, name=code.replace('-', ' '), floor=floor, sector=sector, category=category))
        db.session.commit()
        labels = {"BA-02": "BA-02 · Óleo", "BA-16": "BA-16 · São Curb", "BA-09": "BA-09 · Colina",
                  "BALANCA-SAL": "Balança de sal", "VG-16": "VG-16 · ao lado da VG-17, no chão",
                  "VG-15": "VG-15 · dentro do misturador", "EC-02-5P": "EC-02 · Premix"}
        for code, name in labels.items():
            item = Equipment.query.filter_by(code=code).first()
            if item and item.name == code.replace('-', ' '): item.name = name
        db.session.commit()
        for source, target in EDGES:
            src = Equipment.query.filter_by(code=source).first()
            dst = Equipment.query.filter_by(code=target).first()
            if src and dst:
                labels = [x.strip() for x in (src.connections or '').split(';') if x.strip()]
                if target not in labels:
                    labels.append(target); src.connections = '; '.join(labels)
        db.session.commit()
    except Exception as exc:
        app.logger.warning("Inventário inicial não importado: %s", exc)


if __name__ == "__main__":
    if getattr(sys, "frozen", False):
        threading.Timer(1.0, lambda: webbrowser.open("http://127.0.0.1:5000")).start()
    app.run(host="127.0.0.1", port=5000, debug=False)
