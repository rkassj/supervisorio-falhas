import unittest
from app import app, User

class SimeSmokeTests(unittest.TestCase):
    def setUp(self):
        app.config.update(TESTING=True)
        self.client = app.test_client()

    def login(self, username, password):
        return self.client.post('/login', data={'username': username, 'password': password}, follow_redirects=True)

    def test_login_page_and_role_redirect(self):
        self.assertEqual(self.client.get('/login').status_code, 200)
        self.login('producao', 'prod12345')
        response = self.client.get('/', follow_redirects=True)
        self.assertEqual(response.status_code, 200)  # production is sent to its own area
        self.assertIn('/novo', response.request.path)

    def test_production_permissions(self):
        self.login('producao', 'prod12345')
        self.assertEqual(self.client.get('/novo').status_code, 200)
        self.assertEqual(self.client.get('/meus-chamados').status_code, 200)
        self.assertEqual(self.client.get('/relatorios').status_code, 403)
        self.assertEqual(self.client.get('/equipamentos').status_code, 403)
        self.assertEqual(self.client.get('/equipamento/1').status_code, 403)

    def test_maintenance_permissions(self):
        self.login('manutencao', 'manut12345')
        self.assertEqual(self.client.get('/').status_code, 200)
        self.assertEqual(self.client.get('/relatorios').status_code, 200)
        self.assertEqual(self.client.get('/novo').status_code, 403)
        self.assertEqual(self.client.get('/admin/usuarios').status_code, 403)

    def test_admin_permissions_and_apis(self):
        self.login('admin', 'admin12345')
        self.assertEqual(self.client.get('/equipamentos').status_code, 200)
        self.assertEqual(self.client.get('/admin/usuarios').status_code, 200)
        self.assertEqual(self.client.get('/planta').status_code, 200)
        self.assertEqual(self.client.get('/relatorios').status_code, 200)
        self.assertEqual(self.client.get('/api/health').json['version'], '3.2')
        self.assertEqual(self.client.get('/api/dashboard').status_code, 200)

if __name__ == '__main__':
    unittest.main()
