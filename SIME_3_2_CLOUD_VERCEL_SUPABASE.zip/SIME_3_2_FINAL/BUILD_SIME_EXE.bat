@echo off
setlocal
cd /d "%~dp0"
title Build SIME 3.2 Windows App
 echo ============================================
 echo       GERANDO EXECUTAVEL SIME 3.2
 echo ============================================
where py >nul 2>nul
if errorlevel 1 (
 echo Python nao encontrado. Instale Python 3.10+ e marque Add Python to PATH.
 pause
 exit /b 1
)
py -m pip install --upgrade pip
py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
py -m PyInstaller --noconfirm --clean --onefile --windowed --name SIME_3_2 --icon "static\img\sime-icon.ico" --add-data "templates;templates" --add-data "static;static" app.py
if errorlevel 1 goto fail
 echo.
 echo Build concluido! EXE em dist\SIME_3_2.exe
 echo Copie o EXE para uma pasta normal e execute-o. O banco sera salvo na pasta SIME_data.
 pause
 exit /b 0
:fail
 echo Falha na compilacao. Verifique mensagens acima.
 pause
 exit /b 1
